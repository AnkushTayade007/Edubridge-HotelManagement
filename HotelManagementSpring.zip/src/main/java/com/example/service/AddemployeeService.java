//package com.example.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.example.demo.DAO.AddemployeeDAO;
//import com.example.demo.DAO.AddroomDAO;
//import com.example.model.Addemployee;
//import com.example.model.Addroom;
//
//@Service
//public class AddemployeeService {
//	@Autowired
//	AddemployeeDAO dp;
//	public AddemployeeService() {}
//	
//	//post or save 
//		public void saveAddemployee(Addemployee r) {
//			dp.save(r);
//		}
//
//
//}
