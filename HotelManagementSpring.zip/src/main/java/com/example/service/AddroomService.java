package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.RegisterModel;
import com.example.demo.DAO.AddroomDAO;
import com.example.model.Addroom;

@Service
public class AddroomService {
	@Autowired
	AddroomDAO dp;
	public AddroomService() {}
	
	//post or save 
		public void saveAddroom(Addroom r) {
			dp.save(r);
		}

}
