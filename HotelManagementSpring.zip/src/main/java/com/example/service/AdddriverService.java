//package com.example.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.example.demo.DAO.AdddriverDAO;
//import com.example.demo.DAO.AddemployeeDAO;
//import com.example.model.Adddriver;
//import com.example.model.Addemployee;
//
//@Service
//public class AdddriverService {
//	@Autowired
//	AdddriverDAO dp;
//	public AdddriverService() {}
//	
//	//post or save 
//		public void saveAdddriver(Adddriver r) {
//			dp.save(r);
//		}
//
//}
