package com.example.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Addroom {
	@Id
	int rnumber;
	String date;
	String roomavailable;
	String bedtype;
	int Price;
	
	public Addroom() {}
	
	
	public Addroom(int rnumber,String date, String roomavailable, String bedtype, int Price) {
		super();
		this.rnumber = rnumber;
		this.date = date;
		this.roomavailable = roomavailable;
		this.bedtype = bedtype;
		this.Price = Price;
	}


	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}


	public int getRnumber() {
		return rnumber;
	}


	public void setRnumber(int rnumber) {
		this.rnumber = rnumber;
	}


	public String getRoomavailable() {
		return roomavailable;
	}


	public void setRoomavailable(String roomavailable) {
		this.roomavailable = roomavailable;
	}


	public String getBedtype() {
		return bedtype;
	}


	public void setBedtype(String bedtype) {
		this.bedtype = bedtype;
	}


	public int getPrice() {
		return Price;
	}


	public void setPrice(int price) {
		Price = price;
	}

}
