package com.example.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Addemployee {
	@Id
	String fname;
	int Age;
	String Job;
	int Salary;
	long cnumber;
	long anumber;
	
	public Addemployee() {}
	
	
	public Addemployee(String fname,int Age,String Job,int Salary,long cnumber,long anumber) {
		super();
		this.fname = fname;
		this.Age = Age;
		this.Job = Job;
		this.Salary = Salary;
		this.cnumber = cnumber;
		this.anumber = anumber;
	}


	public String getFname() {
		return fname;
	}


	public void setFname(String fname) {
		this.fname = fname;
	}


	public int getAge() {
		return Age;
	}


	public void setAge(int age) {
		Age = age;
	}


	public String getJob() {
		return Job;
	}


	public void setJob(String job) {
		Job = job;
	}


	public int getSalary() {
		return Salary;
	}


	public void setSalary(int salary) {
		Salary = salary;
	}


	public long getCnumber() {
		return cnumber;
	}


	public void setCnumber(long cnumber) {
		this.cnumber = cnumber;
	}


	public long getAnumber() {
		return anumber;
	}


	public void setAnumber(long anumber) {
		this.anumber = anumber;
	}

}
