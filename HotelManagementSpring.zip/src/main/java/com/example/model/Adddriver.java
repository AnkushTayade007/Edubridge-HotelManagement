package com.example.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Adddriver {
	@Id
	String name;
	int Age;
	String carcompany;
	String carmodel;
	String avail;
	String location;
	
	public Adddriver() {}
	
	
	public Adddriver(int Age,String name, String carcompany, String carmodel, String avail,String location) {
		super();
		this.Age = Age;
		this.name = name;
		this.carcompany = carcompany;
		this.carmodel = carmodel;
		this.avail = avail;
		this.location = location;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getAge() {
		return Age;
	}


	public void setAge(int age) {
		Age = age;
	}


	public String getCarcompany() {
		return carcompany;
	}


	public void setCarcompany(String carcompany) {
		this.carcompany = carcompany;
	}


	public String getCarmodel() {
		return carmodel;
	}


	public void setCarmodel(String carmodel) {
		this.carmodel = carmodel;
	}


	public String getAvail() {
		return avail;
	}


	public void setAvail(String avail) {
		this.avail = avail;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


}
