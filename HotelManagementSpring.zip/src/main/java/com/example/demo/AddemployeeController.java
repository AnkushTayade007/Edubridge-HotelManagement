package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Addemployee;
import com.example.model.Addroom;
import com.example.service.AddemployeeService;
import com.example.service.AddroomService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class AddemployeeController {
	@Autowired
	private AddemployeeService repo;
	
	@PostMapping("insertEmployee")
	public void saveP(@RequestBody Addemployee r) {
		repo.saveAddemployee(r);
	}

}
