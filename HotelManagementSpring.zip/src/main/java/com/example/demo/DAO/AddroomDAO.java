package com.example.demo.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.RegisterModel;
import com.example.model.Addroom;

@Repository
public interface AddroomDAO extends JpaRepository<Addroom,Integer> {

}
