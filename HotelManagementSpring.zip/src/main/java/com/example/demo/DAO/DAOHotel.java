package com.example.demo.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.RegisterModel;

public interface DAOHotel extends JpaRepository<RegisterModel,Integer>{
	
	RegisterModel findByEmail(String Email);
}
