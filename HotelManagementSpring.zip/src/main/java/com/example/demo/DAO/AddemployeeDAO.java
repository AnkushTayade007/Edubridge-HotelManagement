package com.example.demo.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.model.Addemployee;
import com.example.model.Addroom;

public interface AddemployeeDAO  extends JpaRepository<Addemployee,Integer> {

}
