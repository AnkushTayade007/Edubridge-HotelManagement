package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.DAOHotel;

import java.util.ArrayList;


@Service
public class RegisterService {
	@Autowired
	DAOHotel dp;
	public RegisterService() {}

	public List<RegisterModel> getAllRegister() {
		return dp.findAll();
	}
	//Get Register
	public RegisterModel getRegister(int id) {
		
		return dp.getOne(id);
	}
	//post or save 
	public void savePlayer(RegisterModel r) {
		dp.save(r);
	}
}
