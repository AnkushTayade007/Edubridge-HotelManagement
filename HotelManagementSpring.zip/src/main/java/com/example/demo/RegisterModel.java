package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class RegisterModel {
	
    String fname;
	int cnumber;
	String address;
	@Id
	String email;
	String password;
	
	public RegisterModel() {}
	
	
	public RegisterModel(String fname, int cnumber, String address, String email, String password) {
		super();
		this.fname = fname;
		this.cnumber = cnumber;
		this.address = address;
		this.email = email;
		this.password = password;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public int getCnumber() {
		return cnumber;
	}
	public void setCnumber(int cnumber) {
		this.cnumber = cnumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	


}
