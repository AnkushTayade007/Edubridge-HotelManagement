//package com.example.demo;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.example.model.Adddriver;
//import com.example.model.Addemployee;
//import com.example.service.AdddriverService;
//import com.example.service.AddemployeeService;
//
//@RestController
//@CrossOrigin(origins="http://localhost:4200")
//public class AdddriverController {
//	@Autowired
//	private AdddriverService repo;
//	
//	@PostMapping("insertDriver")
//	public void saveP(@RequestBody Adddriver r) {
//		repo.saveAdddriver(r);
//	}
//
//}
