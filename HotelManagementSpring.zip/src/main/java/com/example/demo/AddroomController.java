package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DAO.AddroomDAO;
import com.example.model.Addroom;
import com.example.service.AddroomService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class AddroomController {
	@Autowired
	private AddroomService repo;
	
	@PostMapping("insertRoom")
	public void saveP(@RequestBody Addroom r) {
		repo.saveAddroom(r);
	}
}
