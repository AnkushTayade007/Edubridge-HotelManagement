package com.example.demo;

import java.util.List;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.DAO.DAOHotel;

@RestController
@CrossOrigin(origins="http://localhost:4200")
//@RequestMapping("/register")
public class RegisterController {
	@Autowired
	private DAOHotel repo;
	
	
	@Autowired
	RegisterService ps;
	@GetMapping("view")
	public List<RegisterModel> getPlayers(){

		return ps.getAllRegister();
	}
	
//	public RegisterModel getP(@PathVariable int id) {
//		return ps.getRegister(id);
//	}
	@PostMapping("login")
	public ResponseEntity<?> login(@RequestBody RegisterModel registerData) {
		System.out.println("hello");
		RegisterModel login=repo.findByEmail(registerData.getEmail());
		if(login.getPassword().equals(registerData.getPassword()))
			return ResponseEntity.ok(login);
			return (ResponseEntity<?>) ResponseEntity.internalServerError();
	}
		
	
//	
	@PostMapping("insert")
	public void saveP(@RequestBody RegisterModel r) {
		ps.savePlayer(r);
	}
	

}
