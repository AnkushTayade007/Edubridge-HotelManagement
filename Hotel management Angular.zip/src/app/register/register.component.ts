import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegisterService } from '../register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private router:Router, private rs:RegisterService ){}
  insertdetails(insertdata:any){
    this.rs.insertService(insertdata.value).subscribe();
    this.router.navigateByUrl('/login');

    console.log(insertdata.value);

  }

  goToPage(pageName:string):void{
    this.router.navigate(['${}']);
  }
  ngOnInit(): void {
  }

}
