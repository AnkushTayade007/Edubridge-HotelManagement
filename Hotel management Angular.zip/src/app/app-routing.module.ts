import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './Component/home/home.component'
import { LoginComponent } from './Component/login/login.component';
import { RegisterComponent } from './register/register.component';
import { ContactComponent } from './contact/contact.component';
import { AddEmployeeComponent } from './Admin/add-employee/add-employee.component';
import { AddroomComponent } from './Admin/addroom/addroom.component';
import { AddDriverComponent } from './Admin/add-driver/add-driver.component';
import { UserOptionComponent } from './component/user-option/user-option.component';

const routes: Routes = [
  {path:'login', component:LoginComponent},
  {path:'home', component:HomeComponent},
  {path:'Register',component:RegisterComponent},
  {path:'contact',component:ContactComponent},
  {path:'add-employee',component:AddEmployeeComponent },
  {path:'addroom',component:AddroomComponent},
  {path:'add-driver',component:AddDriverComponent},
  {path:'user-option',component:UserOptionComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
