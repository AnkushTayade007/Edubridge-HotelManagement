import { Component, OnInit } from '@angular/core';
import{Router} from '@angular/router';
import { LoginService } from 'src/app/login.service';
import { RegisterService } from 'src/app/register.service';
import { User } from 'src/app/User';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {   
  

user : User = new User();

  // constructor(private router:Router,private rs:RegisterService){}
constructor( private router: Router, private loginservice:LoginService  ){ }

  
  ngOnInit(): void {
  }
  // goToPage(pageName:String){
  //   this.router.navigate(['$()']);
  // }
  // userLogin(){
  //   console.log(this.user)
  // }
  login1(){
console.log("Hello Component")
this.loginservice.login(this.user).subscribe(data=>{
  alert("Login successfully")
  this.router.navigateByUrl('/user-option');
},error=>alert("Sorry please enter correct email and password"));

}
}
