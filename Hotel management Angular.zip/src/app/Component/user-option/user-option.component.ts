import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-option',
  templateUrl: './user-option.component.html',
  styleUrls: ['./user-option.component.css']
})
export class UserOptionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
