import { TestBed } from '@angular/core/testing';

import { HotelsystemService } from './hotelsystem.service';

describe('HotelsystemService', () => {
  let service: HotelsystemService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HotelsystemService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
