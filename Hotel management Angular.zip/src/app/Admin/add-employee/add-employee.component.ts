import { Component, OnInit } from '@angular/core';
import { HotelsystemService } from 'src/app/hotelsystem.service';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  constructor( private ps:HotelsystemService) { }
  
  insertAddemployee(insertaddemployee:any){
   this.ps.insertAddemployee1(insertaddemployee.value).subscribe(response=>{
    alert("Add Employee Successfull!!");
  },error=>alert("Add Employee not successfull!! Please try again"));
  }

  ngOnInit(): void {
  }

}
