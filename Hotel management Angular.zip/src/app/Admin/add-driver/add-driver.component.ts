import { Component, OnInit } from '@angular/core';
import { HotelsystemService } from 'src/app/hotelsystem.service';

@Component({
  selector: 'app-add-driver',
  templateUrl: './add-driver.component.html',
  styleUrls: ['./add-driver.component.css']
})
export class AddDriverComponent implements OnInit {

  constructor( private ps:HotelsystemService) { }
  
  insertAdddriver(insertadddriver:any){
   this.ps.insertAdddriver1(insertadddriver.value).subscribe(response=>{
    alert("Add Driver Successfull!!");
  },error=>alert("Add Driver not successfull!! Please try again"));
  }


  ngOnInit(): void {
  }

}
