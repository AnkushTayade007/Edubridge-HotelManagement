import { Component, OnInit } from '@angular/core';
import { HotelsystemService } from 'src/app/hotelsystem.service';

@Component({
  selector: 'app-addroom',
  templateUrl: './addroom.component.html',
  styleUrls: ['./addroom.component.css']
})
export class AddroomComponent implements OnInit {

  constructor( private ps:HotelsystemService) { }
  
  insertAddroom(insertaddroom:any){
   this.ps.insertAddroom1(insertaddroom.value).subscribe(response=>{
    alert("Add Room Successfull!!");
  },error=>alert("Add Room not successfull!! Please try again"));
  }

  ngOnInit(): void {
  }
 
}
