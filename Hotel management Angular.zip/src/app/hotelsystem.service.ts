import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HotelsystemService {

  url1 = "http://localhost:8080/insertRoom"
  url2 = "http://localhost:8080/insertEmployee"
  url3 = "http://localhost:8080/insertDriver"
  
  constructor(private h1: HttpClient) {

  }
 
  insertAddroom1(data: any) {
    return this.h1.post(this.url1, data); //post belonging to httpclient

  }

  insertAddemployee1(data: any) {
    return this.h1.post(this.url2, data); //post belonging to httpclient

  }

  insertAdddriver1(data: any) {
    return this.h1.post(this.url3, data); //post belonging to httpclient

  }
  

  
}
