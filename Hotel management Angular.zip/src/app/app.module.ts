import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavigationComponent } from './Component/navigation/navigation.component';
import { IntroComponent } from './Component/intro/intro.component';
import { FooterComponent } from './Component/footer/footer.component';
import { HomeComponent } from './Component/home/home.component';
import { LoginComponent } from './Component/login/login.component';
import { RegisterComponent } from './register/register.component';
import { ContactComponent } from './contact/contact.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AddEmployeeComponent } from './Admin/add-employee/add-employee.component';
import { AddroomComponent } from './Admin/addroom/addroom.component';
import { AddDriverComponent } from './Admin/add-driver/add-driver.component';
import { UserOptionComponent } from './component/user-option/user-option.component';

@NgModule({
  declarations: [
    AppComponent,
    NavigationComponent,
    IntroComponent,
    FooterComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    ContactComponent,
    AddEmployeeComponent,
    AddroomComponent,
    AddDriverComponent,
    UserOptionComponent
  
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
